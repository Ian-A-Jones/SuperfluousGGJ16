﻿using UnityEngine;
using System.Collections;

public struct VillagerAnimData
{
    public float move;
    public bool jump;
    public bool attack;
    public bool dead;
}
